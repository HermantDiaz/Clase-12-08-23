package Calcular;


public class Operador {
    
    int dato1,dato2, resultado;


    public Operador() {
        
        System.out.println("Constructor de Operador");
    
    }
    
    
    // Métodos

    public void setSuma(int a, int b) {
        this.dato1 = a;
        this.dato2 = b;
        this.resultado = dato1 + dato2;
        
    }

    public void setResta(int a, int b) {
        this.dato1 = a;
        this.dato2 = b;
        this.resultado = dato1 - dato2;
        
    }

    
    public void setDivision(int a, int b) {
    this.dato1 = a;
    this.dato2 = b;
    this.resultado = dato1 / dato2;
        
    }
    
    public void setMultiplicacion(int a, int b) {
    this.dato1 = a;
    this.dato2 = b;
    this.resultado = dato1 * dato2;
        
    }
      
    public void impResultado(){
        System.out.println("EL RESULTADO ES: "+resultado);
    }
    
}
