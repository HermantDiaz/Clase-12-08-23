package operador;

public class Operador {

 
    public static void main(String[] args) {
        //objeto de la clase Aritmetica
        Aritmetica contador = new Aritmetica();
    
        contador.suma();
   
        
    }
    
}
