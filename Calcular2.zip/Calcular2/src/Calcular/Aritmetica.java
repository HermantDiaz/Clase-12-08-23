
package Calcular;

import javax.swing.JOptionPane;


public class Aritmetica {
    public Aritmetica(){ 
        //constructor de objeto 
          System.out.println("Constructor de la clase aritmetica"); 
    } 
// Métodos 
   public void suma() 
    { 
    String cadena; 
       int num1; 
       int num2; 
       cadena=JOptionPane.showInputDialog("Introduzca el número 1"); 
       num1=Integer.parseInt(cadena); 
        
       cadena=JOptionPane.showInputDialog("Introduzca el número 2"); 
       num2=Integer.parseInt(cadena); 
        
       JOptionPane.showMessageDialog(null, "La suma es: "+(num1+num2)); 
    } 
}
