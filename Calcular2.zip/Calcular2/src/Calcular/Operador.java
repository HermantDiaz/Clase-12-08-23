
package Calcular;


public class Operador {
    
    int dato1, dato2, resultado=0; 
    
        public Operador(){ 
        //constructor de objeto 
          System.out.println("Constructor de la clase operador"); 
    } 
// Métodos 
   public void setSuma(int a, int b){ 
        this.dato1=a; 
        this.dato2=b; 
        this.resultado=dato1 + dato2; 
    } 
     public void setResta(int a, int b){ 
        this.dato1=a; 
        this.dato2=b; 
        this.resultado=dato1 - dato2; 
    } 
      public void setDivision(int a, int b){ 
        this.dato1=a; 
        this.dato2=b; 
        this.resultado=dato1 / dato2;             
    } 
        public void setMultiplicacion(int a, int b){ 
        this.dato1=a; 
        this.dato2=b; 
        this.resultado=dato1 * dato2;             
    } 
        public void impResultado(){ 
            System.out.println("El resultado es = "+resultado);
        } 


       

        
        
        
}
