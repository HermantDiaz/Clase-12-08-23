package Calcular;


public class Calcular {

    public static void main(String[] args) {
 
        Operador contador = new Operador();
        
        
        contador.setSuma(20, 4);
        contador.impResultado();
        
        contador.setResta(20, 4);
        contador.impResultado();
        
        
        contador.setMultiplicacion(20, 4);
        contador.impResultado();
        
        contador.setDivision(20, 4);
        contador.impResultado();
        
     
    }
    
}
