
package operador;

import javax.swing.JOptionPane;

public class Aritmetica {

    //constructor
    public Aritmetica() {
        System.out.println("Constructor de Aritmetica");
    }
    
    public void suma(){
    
    String cadena;
    
    int num1, num2;
    
    cadena = JOptionPane.showInputDialog("Instroduzca el numero uno");
    num1 = Integer.parseInt(cadena);
    
    cadena = JOptionPane.showInputDialog("Instroduzca el numero dos");
    num2 = Integer.parseInt(cadena);
    
    JOptionPane.showMessageDialog(null, "La suma de los dos numeros es: " + (num1 + num2));
    
    }
    
    
}
