package Calcular;

public class Calcular2 {


    public static void main(String[] args) {
    Operador contador = new Operador(); 
    Aritmetica contador1 = new Aritmetica(); 

     contador.setSuma(25, 4); 
     contador.impResultado(); 
     contador.setResta(20, 4); 
     contador.impResultado(); 
     contador.setDivision(20, 2); 
     contador.impResultado(); 
     contador.setMultiplicacion(10, 4); 
     contador.impResultado(); 
     contador1.suma(); 
        
        
    }
    
}
